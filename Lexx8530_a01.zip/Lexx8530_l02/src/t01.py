"""
------------------------------------------------------------------------
[program description]
converting celsuis to fahrenheit
------------------------------------------------------------------------
Author: Tommy Le
ID:     200298530
Email:  lexx8530@mylaurier.ca
__updated__ = "2020-09-17"
------------------------------------------------------------------------
"""
celsius = int(input("Temperature (C): "))

fahrenheit = int(9/5*celsius +32)

print("Temperature (F): ", fahrenheit)

"""
------------------------------------------------------------------------
[program description]
Multiplying fractions
------------------------------------------------------------------------
Author: Tommy Le
ID:     200298530
Email:  lexx8530@mylaurier.ca
__updated__ = "2020-09-24"
------------------------------------------------------------------------
"""
n1 = int(input("First numerator: "))
d1 = int(input("First demoninator: "))

n2 = int(input("Second numerator: "))
d2 = int(input("Second denominator: "))

total = n1/d1 * n2/d2

print("Product: {:.2f}".format(total))
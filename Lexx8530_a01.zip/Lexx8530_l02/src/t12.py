"""
------------------------------------------------------------------------
[program description]
converting seconds to days, hours, minutes, and seconds
------------------------------------------------------------------------
Author: Tommy Le
ID:     200298530
Email:  lexx8530@mylaurier.ca
__updated__ = "2020-09-24"
------------------------------------------------------------------------
"""
number_seconds = int(input("Number of seconds: "))

days = number_seconds // (24 * 3600)

number_seconds = number_seconds % (24 * 3600)
hours = number_seconds // 3600

number_seconds %= 3600
minutes = number_seconds // 60

number_seconds %= 60
seconds = number_seconds

print("Days:{},".format(days), "Hours:{},".format(hours), "Minutes:{},".format(minutes), "Seconds:{},".format(seconds))
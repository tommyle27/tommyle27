"""
------------------------------------------------------------------------
[program description]
Assigns number of flyers to volenteer
------------------------------------------------------------------------
Author: Tommy Le
ID:     200298530
Email:  lexx8530@mylaurier.ca
__updated__ = "2020-09-24"
------------------------------------------------------------------------
"""
num_flyers = int(input("Number of flyers: "))
num_vol = int(input("Number of volunteers: "))

flyers_per_vol = num_flyers // num_vol
left_over = num_flyers % num_vol

print("Flyers per volunteer: ", flyers_per_vol)
print("Flyers left over: ", left_over)
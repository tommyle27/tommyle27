"""
------------------------------------------------------------------------
[program description]
calculating profit off annual sales
------------------------------------------------------------------------
Author: Tommy Le
ID:     200298530
Email:  lexx8530@mylaurier.ca
__updated__ = "2020-09-24"
------------------------------------------------------------------------
"""
annual_sales = float(input("Enter projected annual sales: $"))

Percent = float(0.18)

profit = float(annual_sales * Percent)

print("The projected profit on sales of ${:.2f}".format(annual_sales), "is ${:.2f}".format(profit))
